package Modelo.DAO;
import Modelo.Cliente;
import java.util.*;

import Modelo.ClienteEstandar;
import Modelo.ClientePremium;
import Modelo.Hibernate;
import org.hibernate.*;

<<<<<<< HEAD
=======
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import Modelo.Hibernate;
import org.hibernate.*;

>>>>>>> 326441c68f2aaa0b47abbde9fc4d74ab63a39fea
public class ClienteDAOImpl implements ClienteDAO {

    private SessionFactory sessionFactory;

    public ClienteDAOImpl () {
        this.sessionFactory = Hibernate.getSessionFactory();
    }

    @Override
    public void insert(Modelo.Cliente cliente) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(cliente);
            transaction.commit();
        }
    }

    @Override
<<<<<<< HEAD
    public ArrayList<Cliente> readAll() {
        try (Session session = sessionFactory.openSession()) {
            ArrayList<Cliente> cl = new ArrayList<Cliente>();
           ArrayList<ClienteEstandar> ce = (ArrayList<ClienteEstandar>) session.createQuery("FROM ClienteEstandar", ClienteEstandar.class).list();
           ArrayList<ClientePremium> cp = (ArrayList<ClientePremium>) session.createQuery("FROM ClientePremium", ClientePremium.class).list();
           cl.addAll(ce);
           cl.addAll(cp);
           return cl;
=======
    public ArrayList<Cliente>readAll(){
        try (Session session = sessionFactory.openSession()) {
            return (ArrayList<Cliente>) session.createQuery("FROM EntidadTabla", Cliente.class).list();
>>>>>>> 326441c68f2aaa0b47abbde9fc4d74ab63a39fea
        }
    }

    public Cliente findById(String id) {
        try (Session session = sessionFactory.openSession()) {
            Cliente art = session.get(Cliente.class, id);
            return art;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void update(Cliente cliente) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.update(cliente);
            transaction.commit();
        }
    }

}