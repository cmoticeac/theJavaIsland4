package Vista;

/**
 * Esta es la clase principal del programa.
 * Descripción adicional de la clase...
 */
public class OnlineStore {
    public static void main(String[] args) {
        GestionOS gestion = new GestionOS();
        gestion.Inicio();
    }

    public static class Main {
        public static void main(String[] args) {
            System.out.println("Hello world!");
        }
    }
}
